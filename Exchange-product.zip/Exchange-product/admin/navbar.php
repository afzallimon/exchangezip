<nav class="menu" id="nav">
	<span class="nav-item active">
		<span class="icon">
			<i data-feather="home"></i>
		</span>
		<a href="index.php">Home</a>
	</span>
	<span class="nav-item">
		<span class="icon">
			<i data-feather="search"></i>
		</span>
		<a href="result.php">Search</a>
	</span>
	<span class="nav-item">
		<span class="icon">
			<span class="subicon">13</span>
			<i data-feather="bell"></i>
		</span>
		<a href="vieworder.php">All Order</a>
	</span>
	<span class="nav-item">
		<span class="icon">
			<i data-feather="star"></i>
		</span>
		<a href="#">Favorites</a>
	</span>
</nav>